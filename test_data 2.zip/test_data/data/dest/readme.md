# UCL Research Fellow – Technical Test Submission

This repository contains the completed technical test for the Research Fellow post at UCL, using synthetic health data generated via the [Synthea](https://synthetichealth.github.io/synthea/) platform.

---

## 📊 Project Summary

The notebook performs the following:

- Loads and cleans five core EHR datasets (patients, conditions, observations, encounters, medications)
- Integrates SNOMED, RxNorm, and LOINC dictionaries for interpretability
- Describes patient demographics and clinical data distributions
- Identifies patients with hypertension
- Analyses BMI and blood pressure among hypertensive patients vs non-hypertensives
- Calculates both **crude** and **UK-age-adjusted** hypertension prevalence
- Visualises key trends using Seaborn and Matplotlib

---

## 📁 Files

- `synthea_analysis.ipynb`: Clean, well-annotated Jupyter notebook with full workflow
- `data/`: Folder containing raw `.csv.gz` files and lookup dictionaries (not included here due to size)
- `README.md`: This file

---

## 🧪 Environment

- Python 3.9+
- Jupyter Notebook
- Libraries: `pandas`, `numpy`, `seaborn`, `matplotlib`

You can install dependencies via:

```bash
pip install -r requirements.txt
